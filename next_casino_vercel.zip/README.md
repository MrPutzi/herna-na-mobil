Short SK README

1) Upload project to GitHub (Upload files on GitHub web).
2) In Vercel create project from this repo.
3) Add Environment Variables in Vercel:
   - DATABASE_URL (Postgres connection string)
   - JWT_SECRET
   - DB_SSL=true
4) Create DB table using migrations/init.sql (psql or Vercel Postgres admin).
5) Deploy and test UI.

Note: demo — virtual credits only. No payments or legal compliance.
